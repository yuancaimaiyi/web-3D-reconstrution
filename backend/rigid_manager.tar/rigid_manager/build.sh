mkdir -p build
cd build
cmake ..
make

make package

./RigidManager-test ../sample_data/