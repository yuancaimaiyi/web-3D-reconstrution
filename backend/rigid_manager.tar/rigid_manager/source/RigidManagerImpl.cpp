#include "RigidManagerImpl.hpp"

#include <cstring>
#include <dirent.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>

#ifdef LINUX
#include <sys/stat.h>
#include <sys/statfs.h>
#endif
#ifdef DARWIN
#include <sys/mount.h>
#include <sys/param.h>
#endif

#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/types.h>
#include <yaml-cpp/yaml.h>

#include "json.hpp"

namespace wayz {
namespace calibration {

static void parseCameraInfo(const YAML::Node& rawInfo, NodeInfo& info)
{
    if (rawInfo["resolution"].IsDefined() && rawInfo["resolution"].IsSequence() && rawInfo["resolution"].size() == 2) {
        info.cameraInfo.resolution[0] = rawInfo["resolution"][0].as<int32_t>();
        info.cameraInfo.resolution[1] = rawInfo["resolution"][1].as<int32_t>();
    } else {
        throw std::runtime_error("Can not read resolution");
    }

    if (rawInfo["intrinsics"].IsDefined() && rawInfo["intrinsics"].IsSequence()) {
        for (auto& n : rawInfo["intrinsics"]) {
            info.cameraInfo.intrinsics.emplace_back(n.as<double>());
        }
    } else {
        throw std::runtime_error("Can not read intrinsics");
    }

    if (rawInfo["distortion_coeffs"].IsDefined() && rawInfo["distortion_coeffs"].IsSequence()) {
        for (auto& n : rawInfo["distortion_coeffs"]) {
            info.cameraInfo.distortionCoefficients.emplace_back(n.as<double>());
        }
    } else {
        throw std::runtime_error("Can not read distortion_coeffs");
    }

    info.cameraInfo.cameraModel = CameraModelType::Undefined;
    if (rawInfo["camera_model"].IsDefined()) {
        auto model = rawInfo["camera_model"].as<std::string>();
        if (model == "pinhole") {
            info.cameraInfo.cameraModel = CameraModelType::Pinhole;
            if (info.cameraInfo.intrinsics.size() != 4) {
                throw std::runtime_error("Pinhole camera should have 4 intrinsics, given " +
                                         std::to_string(info.cameraInfo.intrinsics.size()));
            }
        } else if (model == "omni") {
            info.cameraInfo.cameraModel = CameraModelType::Omni;
            if (info.cameraInfo.intrinsics.size() != 5) {
                throw std::runtime_error("Omni camera should have 5 intrinsics, given " +
                                         std::to_string(info.cameraInfo.intrinsics.size()));
            }
        } else if (model == "eucm") {
            info.cameraInfo.cameraModel = CameraModelType::EUCM;
            if (info.cameraInfo.intrinsics.size() != 6) {
                throw std::runtime_error("EUCM camera should have 6 intrinsics, given " +
                                         std::to_string(info.cameraInfo.intrinsics.size()));
            }
        } else if (model == "ds") {
            info.cameraInfo.cameraModel = CameraModelType::DS;
            if (info.cameraInfo.intrinsics.size() != 6) {
                throw std::runtime_error("DS camera should have 6 intrinsics, given " +
                                         std::to_string(info.cameraInfo.intrinsics.size()));
            }
        }
    } else {
        throw std::runtime_error("Camera have no model defined");
    }

    info.cameraInfo.distortionModel = DistortionModelType::Undefined;
    if (rawInfo["distortion_model"].IsDefined()) {
        auto model = rawInfo["distortion_model"].as<std::string>();
        if (model == "radtan") {
            info.cameraInfo.distortionModel = DistortionModelType::Radtan;
            if (info.cameraInfo.distortionCoefficients.size() != 4) {
                throw std::runtime_error("Radtan distorted camera should have 4 distortion coefficients, given " +
                                         std::to_string(info.cameraInfo.distortionCoefficients.size()));
            }
        } else if (model == "equidistant") {
            info.cameraInfo.distortionModel = DistortionModelType::Equidistant;
            if (info.cameraInfo.distortionCoefficients.size() != 4) {
                throw std::runtime_error("Equidistant distorted camera should have 4 distortion coefficients, given " +
                                         std::to_string(info.cameraInfo.distortionCoefficients.size()));
            }
        } else if (model == "fov") {
            info.cameraInfo.distortionModel = DistortionModelType::FOV;
            if (info.cameraInfo.distortionCoefficients.size() != 1) {
                throw std::runtime_error("FOV distorted camera should have 1 distortion coefficients, given " +
                                         std::to_string(info.cameraInfo.distortionCoefficients.size()));
                ;
            }
        } else if (model == "none") {
            info.cameraInfo.distortionModel = DistortionModelType::None;
            if (info.cameraInfo.distortionCoefficients.size() != 0) {
                throw std::runtime_error("None distorted camera should have 0 distortion coefficients, given " +
                                         std::to_string(info.cameraInfo.distortionCoefficients.size()));
            }
        }
    } else {
        throw std::runtime_error("Camera have no distortion model defined");
    }
}

RigidManagerImpl::RigidManagerImpl(const std::string& path, const std::vector<std::string>& nodeNames)
{
    isValid_ = false;
    graph_.edges.clear();
    graph_.nodes.clear();
    graph_.connectedComponents.clear();
    transformationCache_.clear();

    for (auto& nodeName : nodeNames) {
        graph_.nodes[nodeName] = {};
    }

    auto dir = opendir(path.c_str());
    if (!dir) {
        std::cerr << "RigidManager: Can not open folder '" << path << "'" << std::endl;
    }

    while (auto node = readdir(dir)) {
        if (strcmp(node->d_name, ".") == 0 || strcmp(node->d_name, "..") == 0) {
            continue;
        }

        std::string basename = node->d_name;
        std::string fullname = path + "/" + basename;
        struct stat stat_result;
        if (stat(fullname.c_str(), &stat_result)) {
            continue;
        }

        if (!S_ISREG(stat_result.st_mode)) {
            continue;
        }

        if (basename.size() < 4) {
            continue;
        }

        std::string extension = basename.substr(basename.size() - 4, basename.size());
        if (extension == "yaml") {
            if (!loadYaml(fullname)) {
                std::cerr << "RigidManager: Can not load yaml '" << fullname << "'" << std::endl;
                closedir(dir);
                return;
            }
        } else if (extension == "json") {
            if (!loadJson(fullname)) {
                std::cerr << "RigidManager: Can not load json '" << fullname << "'" << std::endl;
                closedir(dir);
                return;
            }
        } else {
            std::cerr << "RigidManager: folder file '" << basename << "', is not 'json' nor 'yaml', ignored"
                      << std::endl;
        }
    }
    closedir(dir);

    calculateGraph();
}

bool RigidManagerImpl::isValid() const
{
    return isValid_;
}

bool RigidManagerImpl::isConnected() const
{
    if (isValid_) {
        return graph_.connectedComponents.size() == 1;
    }
    return false;
}

bool RigidManagerImpl::isAcyclic() const
{
    if (isValid_) {
        return graph_.isAcyclic;
    }
    return false;
}

bool RigidManagerImpl::isObtainable(const std::string& nodeNameParent, const std::string& nodeNameChild) const
{
    if (nodeNameParent == nodeNameChild) {
        return true;
    }

    if (isValid_) {
        if (transformationCache_.count(nodeNameParent)) {
            if (transformationCache_.at(nodeNameParent).count(nodeNameChild)) {
                return true;
            }
        }
    }

    return false;
}

Transformation RigidManagerImpl::getTransformation(const std::string& nodeNameParent,
                                                   const std::string& nodeNameChild) const
{
    if (nodeNameParent == nodeNameChild) {
        return {};
    }

    if (transformationCache_.count(nodeNameParent)) {
        if (transformationCache_.at(nodeNameParent).count(nodeNameChild)) {
            return transformationCache_.at(nodeNameParent).at(nodeNameChild);
        }
    }

    return {};
}

std::vector<std::string> RigidManagerImpl::getNodeList() const
{
    if (isValid_) {
        std::vector<std::string> keys;

        std::transform(graph_.nodes.begin(), graph_.nodes.end(), std::back_inserter(keys), [](auto&& pair) {
            return pair.first;
        });

        return keys;
    }
    return {};
}

NodeInfo RigidManagerImpl::getNodeInfo(const std::string& nodeName) const
{
    if (isValid_) {
        if (graph_.nodes.count(nodeName)) {
            return graph_.nodes.at(nodeName).nodeInfo;
        }
    }
    return {};
}

///
/// @brief Load yaml formatted camchain
///
bool RigidManagerImpl::loadYaml(const std::string& filePath)
{
    std::ifstream yamlFile(filePath, std::ios::in);
    if (!yamlFile.is_open()) {
        std::cerr << "Can not open yaml file " << filePath << std::endl;
    }
    std::string yamlFileContent((std::istreambuf_iterator<char>(yamlFile)), std::istreambuf_iterator<char>());
    yamlFile.close();

    YAML::Node cameraChainNode = YAML::Load(yamlFileContent);

    Eigen::Matrix4d transform = Eigen::Matrix4d::Identity();
    std::string baseCameraName;
    bool isFirst = true;

    struct NodeWithNumber {
        int32_t index;
        YAML::iterator nodeItr;
    };
    std::vector<NodeWithNumber> sortedNodes;

    for (auto cameraNode = cameraChainNode.begin(); cameraNode != cameraChainNode.end(); ++cameraNode) {
        auto indexName = cameraNode->first.as<std::string>();
        if (indexName.size() < 4) {
            std::cerr << "RigidManager: loadYAML, format error(camera indexName = " << indexName
                      << " not proper), check " << filePath << std::endl;
            return false;
        }
        int32_t index = std::stoi(indexName.substr(3));
        sortedNodes.push_back({index, cameraNode});
    }

    std::sort(sortedNodes.begin(), sortedNodes.end(), [](const auto& l, const auto& r) { return l.index < r.index; });

    for (auto cameraNode = sortedNodes.begin(); cameraNode != sortedNodes.end(); ++cameraNode) {
        const auto& camera = cameraNode->nodeItr->second;

        std::string cameraName;
        {
            auto rosTopic = camera["rostopic"].as<std::string>();
            std::istringstream rosTopicSs(rosTopic);
            std::string token;
            getline(rosTopicSs, token, '/');
            getline(rosTopicSs, token, '/');
            cameraName = token + "_";
            getline(rosTopicSs, token, '/');
            cameraName += token;
        }

        if (isFirst) {
            // Is imu calibration result
            if (camera["T_cam_imu"].IsDefined() && camera["imutopic"].IsDefined()) {
                Eigen::Matrix4d imuTransform;
                for (size_t i = 0; i < 4; ++i) {
                    for (size_t j = 0; j < 4; ++j) {
                        imuTransform(i, j) = camera["T_cam_imu"][i][j].as<double>();
                    }
                }

                std::string imuName;
                {
                    auto imuTopic = camera["imutopic"].as<std::string>();
                    std::istringstream imuTopicSs(imuTopic);
                    std::string token;
                    getline(imuTopicSs, token, '/');
                    getline(imuTopicSs, token, '/');
                    imuName = token + "_";
                    getline(imuTopicSs, token, '/');
                    imuName += token;
                }
                graph_.edges.push_back({imuName, cameraName, imuTransform});
                return true;
            }

            if (camera["T_cn_cnm1"].IsDefined()) {
                std::cerr << "RigidManager: loadYAML, format error(first camera = " << cameraName
                          << " have T_cn_cnm1), check " << filePath << std::endl;
                return false;
            }

            baseCameraName = cameraName;
            isFirst = false;
        } else {
            if (camera["T_cn_cnm1"].IsDefined()) {
                Eigen::Matrix4d incrementalTransform;
                for (size_t i = 0; i < 4; ++i) {
                    for (size_t j = 0; j < 4; ++j) {
                        incrementalTransform(i, j) = camera["T_cn_cnm1"][i][j].as<double>();
                    }
                }
                transform = incrementalTransform * transform;

                graph_.edges.push_back({baseCameraName, cameraName, transform});
            } else {
                std::cerr << "RigidManager: loadYAML, camera " << cameraName << " no extrinsic, check " << filePath
                          << std::endl;
                return false;
            }
        }

        auto& nodeInfo = graph_.nodes[cameraName].nodeInfo;
        try {
            parseCameraInfo(camera, nodeInfo);
        } catch (std::exception& err) {
            std::cerr << "RigidManager: loadYAML, camera " << cameraName << " errored in parse node info, "
                      << err.what() << std::endl;
            return false;
        }
    }
    return true;
}

///
/// @brief Load json formatted transformations
///
bool RigidManagerImpl::loadJson(const std::string& filePath)
{
    using nlohmann::json;

    auto addJsonTransform = [&](json& jsonObj) {
        std::string childNodeName;
        std::string parentNodeName;
        Eigen::Matrix4d transformation = Eigen::Matrix4d::Identity();

        try {
            childNodeName = jsonObj["child"].get<std::string>();
            parentNodeName = jsonObj["parent"].get<std::string>();
            if (childNodeName.empty() || parentNodeName.empty()) {
                throw std::runtime_error("");
            }
        } catch (std::exception& e) {
            std::cerr << "RigidManager: loadJson, parsing " << jsonObj.dump() << ", missing parent or child node name"
                      << std::endl;
            return false;
        }

        if (jsonObj["transformation"].is_array()) {
            if (jsonObj["transformation"].size() == 16) {
                for (size_t i = 0; i < 3; ++i) {
                    for (size_t j = 0; j < 4; ++j) {
                        transformation(i, j) = jsonObj["transformation"].at(4 * i + j).get<double>();
                    }
                }
            } else {
                std::cerr << "RigidManager: loadJson, parsing transformation " << jsonObj["transformation"].dump()
                          << ", transformation size is not matrix 4x4" << std::endl;
                return false;
            }
        } else if (jsonObj["rotation"].is_array() && jsonObj["translation"].is_array()) {
            if (jsonObj["translation"].size() == 3) {
                for (size_t i = 0; i < 3; ++i) {
                    transformation(i, 3) = jsonObj["translation"].at(i).get<double>();
                }
            } else {
                std::cerr << "RigidManager: loadJson, parsing translation " << jsonObj["translation"].dump()
                          << ", translation size is not vector 3x1" << std::endl;
                return false;
            }

            if (jsonObj["rotation"].size() == 9) {
                for (size_t i = 0; i < 3; ++i) {
                    for (size_t j = 0; j < 3; ++j) {
                        transformation(i, j) = jsonObj["rotation"].at(3 * i + j).get<double>();
                    }
                }
            } else if (jsonObj.at("rotation").size() == 4) {
                Eigen::Quaterniond quat;
                quat.x() = jsonObj.at("rotation").at(0).get<double>();
                quat.y() = jsonObj.at("rotation").at(1).get<double>();
                quat.z() = jsonObj.at("rotation").at(2).get<double>();
                quat.w() = jsonObj.at("rotation").at(3).get<double>();

                if (fabs(1 - quat.norm()) > 1e-6) {
                    std::cerr << "RigidManager: loadJson, parsing rotation " << jsonObj.at("rotation").dump()
                              << ", quaternion is not normalized" << std::endl;
                    return false;
                }

                transformation.block<3, 3>(0, 0) = quat.toRotationMatrix();
            } else {
                std::cerr << "RigidManager: loadJson, parsing rotation " << jsonObj.at("rotation").dump()
                          << ", rotation is not matrix 3x3 nor quaternion xyzw" << std::endl;
                return false;
            }
        } else {
            std::cerr << "RigidManager: loadJson, no transformation nor rotation & translation " << jsonObj.dump()
                      << ", format error" << std::endl;
            return false;
        }

        auto rotation = transformation.block<3, 3>(0, 0);
        auto diff = rotation.inverse() - rotation.transpose();
        for (size_t i = 0; i < 3; ++i) {
            for (size_t j = 0; j < 3; ++j) {
                if (fabs(diff(i, j)) > 1e-6) {
                    std::cerr << "RigidManager: loadJson, rotation " << rotation << ", is not unitary" << std::endl;
                    return false;
                }
            }
        }

        graph_.edges.push_back({childNodeName, parentNodeName, transformation});
        return true;
    };

    std::ifstream ifs;
    ifs.open(filePath, std::ios::in);
    if (!ifs.is_open()) {
        std::cerr << "RigidManager: loadJson, can not open file " << filePath << std::endl;
        return false;
    }
    json jsonObj;
    ifs >> jsonObj;
    if (jsonObj.is_array()) {
        for (auto& jsonItr : jsonObj) {
            addJsonTransform(jsonItr);
        }
    } else if (jsonObj.is_object()) {
        addJsonTransform(jsonObj);
    }

    return true;
}

void RigidManagerImpl::dfsGraph(GraphNode& node)
{
    node.markDFS = true;

    for (auto& edge : node.inEdges) {
        if (!edge->mark) {
            edge->mark = true;
            if (!graph_.nodes[edge->nodeNameChild].markDFS) {
                dfsGraph(graph_.nodes[edge->nodeNameChild]);
            } else {
                std::cerr << "RigidManager: Graph Analyser, by adding edge " << edge->nodeNameChild << "->"
                          << edge->nodeNameParent << ", the graph become cyclic" << std::endl;
            }
        }
    }
    for (auto& edge : node.outEdges) {
        if (!edge->mark) {
            edge->mark = true;
            if (!graph_.nodes[edge->nodeNameParent].markDFS) {
                dfsGraph(graph_.nodes[edge->nodeNameParent]);
            } else {
                std::cerr << "RigidManager: Graph Analyser, by adding edge " << edge->nodeNameChild << "->"
                          << edge->nodeNameParent << ", the graph become cyclic" << std::endl;
                graph_.isAcyclic = false;
            }
        }
    }
}

void RigidManagerImpl::dfsCalculate(GraphNode& node)
{
    for (auto& edge : node.inEdges) {
        if (!edge->mark) {
            edge->mark = true;
            Eigen::Matrix4d newTrans = edge->trans.inverse() * node.tempTrans;
            graph_.nodes[edge->nodeNameChild].tempTrans = newTrans;
            graph_.nodes[edge->nodeNameChild].markDFS = true;
            dfsCalculate(graph_.nodes[edge->nodeNameChild]);
        };
    }
    for (auto& edge : node.outEdges) {
        if (!edge->mark) {
            edge->mark = true;
            Eigen::Matrix4d newTrans = edge->trans * node.tempTrans;
            graph_.nodes[edge->nodeNameParent].tempTrans = newTrans;
            graph_.nodes[edge->nodeNameParent].markDFS = true;
            dfsCalculate(graph_.nodes[edge->nodeNameParent]);
        };
    }
}

void RigidManagerImpl::calculateGraph()
{
    for (auto& edge : graph_.edges) {
        graph_.nodes[edge.nodeNameChild].outEdges.push_back(&edge);
        graph_.nodes[edge.nodeNameParent].inEdges.push_back(&edge);
    }

    // do dfs
    for (auto& node : graph_.nodes) {
        node.second.markStart = false;
        node.second.markDFS = false;
    }
    for (auto& edge : graph_.edges) {
        edge.mark = false;
    }
    for (auto& node : graph_.nodes) {
        if (!node.second.markStart) {
            node.second.markStart = true;
            graph_.connectedComponents.push_back({});
            dfsGraph(node.second);
            for (auto& node : graph_.nodes) {
                if (node.second.markDFS) {
                    node.second.markStart = true;
                    node.second.markDFS = false;
                    graph_.connectedComponents.back().push_back(node.first);
                }
            }
        }
    }

    // do cal
    for (auto& node : graph_.nodes) {
        for (auto& edge : graph_.edges) {
            edge.mark = false;
        }
        for (auto& node : graph_.nodes) {
            node.second.markDFS = false;
        }

        node.second.tempTrans = Eigen::Matrix4d(Eigen::Matrix4d::Identity());
        dfsCalculate(node.second);

        transformationCache_[node.first] = {};
        for (auto& nodeParent : graph_.nodes) {
            if (nodeParent.second.markDFS) {
                transformationCache_[node.first][nodeParent.first] = nodeParent.second.tempTrans;
            }
        }
    }

    isValid_ = true;
}


}  // namespace calibration
}  // namespace wayz