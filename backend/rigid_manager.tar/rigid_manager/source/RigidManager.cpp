#include "RigidManager.hpp"

#include "RigidManagerImpl.hpp"

namespace wayz {
namespace calibration {

RigidManager::RigidManager(const std::string& path, const std::vector<std::string>& nodeNames) :
    pImpl_(std::make_unique<RigidManagerImpl>(path, nodeNames))
{}

bool RigidManager::isValid() const
{
    if (pImpl_) {
        return pImpl_->isValid();
    }
    return false;
}

bool RigidManager::isConnected() const
{
    if (pImpl_) {
        return pImpl_->isConnected();
    }
    return false;
}

bool RigidManager::isAcyclic() const
{
    if (pImpl_) {
        return pImpl_->isAcyclic();
    }
    return false;
}

bool RigidManager::isObtainable(const std::string& nodeNameParent, const std::string& nodeNameChild) const
{
    if (pImpl_) {
        return pImpl_->isObtainable(nodeNameParent, nodeNameChild);
    }
    return false;
}

Transformation RigidManager::getTransformation(const std::string& nodeNameParent,
                                               const std::string& nodeNameChild) const
{
    if (pImpl_) {
        return pImpl_->getTransformation(nodeNameParent, nodeNameChild);
    }
    return {};
}

std::vector<std::string> RigidManager::getNodeList() const
{
    if (pImpl_) {
        return pImpl_->getNodeList();
    }
    return {};
}

NodeInfo RigidManager::getNodeInfo(const std::string& nodeName) const
{
    if (pImpl_) {
        return pImpl_->getNodeInfo(nodeName);
    }
    return {};
}

RigidManager::~RigidManager() = default;
RigidManager::RigidManager(RigidManager&& rhs) = default;
RigidManager& RigidManager::operator=(RigidManager&& rhs) = default;

}  // namespace calibration
}  // namespace wayz