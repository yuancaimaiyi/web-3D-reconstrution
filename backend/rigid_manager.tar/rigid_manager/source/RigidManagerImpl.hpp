#pragma once

#include <map>
#include <string>
#include <vector>

#include "NodeInfo.hpp"
#include "Transformation.hpp"

namespace wayz {
namespace calibration {

///
/// @brief Implementation class of RigidManager
///
class RigidManagerImpl final {
public:
    ///
    /// @brief Load transformations from path
    ///
    /// @param path path to folder containing json and yaml formatted
    /// calibration results
    /// @param nodeNames names of nodes of interest
    ///
    RigidManagerImpl(const std::string& path, const std::vector<std::string>& nodeNames);

    ///
    /// @brief Judge if transformations are loaded successfully and ready to use
    ///
    /// @return bool if transformations are loaded successfully and ready to use
    ///
    bool isValid() const;

    ///
    /// @brief Judge if nodes are all connected by valid transformation edges
    ///
    /// @return bool if given nodes () are connected, i.e., transform of arbitrary
    /// node pairs are obtainable.
    ///
    bool isConnected() const;

    ///
    /// @brief Judge if node graph is acyclic
    ///
    /// @return bool if node graph is acyclic, i.e., transformation of arbitrary
    /// node pairs are well-determined.
    ///
    bool isAcyclic() const;

    ///
    /// @brief Judge if transformation between two nodes is obtainable.
    ///
    /// @param nodeNameChild node name of child
    /// @param nodeNameParent node name of parent
    ///
    /// @return bool transformation between given node pairs is obtainable.
    ///
    bool isObtainable(const std::string& nodeNameChild, const std::string& nodeNameParent) const;

    ///
    /// @brief Get the Transformation between child and parent
    ///
    /// @param nodeNameChild node name of child
    /// @param nodeNameParent node name of parent
    ///
    /// @return Transformation T_{parent<-child} satisfies T_pc([R t; 0, 1]) *
    /// x_child(homogenous column vector) = x_parent(homogenous column vector)
    /// if transformation is obtainable return transformation itself, else return arbitrary matrix
    Transformation getTransformation(const std::string& nodeNameChild, const std::string& nodeNameParent) const;

    ///
    /// @brief Get the Node list
    ///
    /// @return std::vector<std::string> node list
    ///
    std::vector<std::string> getNodeList() const;

    ///
    /// @brief Get the Node of node
    ///
    /// @param nodeName node name
    /// @return const NodeInfo& node info of give node
    ///
    NodeInfo getNodeInfo(const std::string& nodeName) const;

private:
    struct GraphEdge {
        std::string nodeNameChild;
        std::string nodeNameParent;
        Transformation trans;
        bool mark{false};
    };

    struct GraphNode {
        NodeInfo nodeInfo;
        std::vector<GraphEdge*> outEdges;
        std::vector<GraphEdge*> inEdges;
        bool markStart{false};
        bool markDFS{false};
        Transformation tempTrans;
    };
    struct Graph {
        std::vector<GraphEdge> edges;
        std::map<std::string, GraphNode> nodes;
        std::vector<std::vector<std::string>> connectedComponents;
        bool isAcyclic{true};
    };

private:
    ///
    /// @brief Load single yaml file, yaml formatted camchain
    ///
    bool loadYaml(const std::string& filePath);

    ///
    /// @brief Load single json file json formatted transformations
    ///
    bool loadJson(const std::string& filePath);

    void calculateGraph();

    void dfsGraph(GraphNode& node);

    void dfsCalculate(GraphNode& node);

private:
    bool isValid_;

    Graph graph_;

    std::map<std::string, std::map<std::string, Transformation>> transformationCache_;
};

}  // namespace calibration
}  // namespace wayz