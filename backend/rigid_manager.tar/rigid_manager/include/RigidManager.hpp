#pragma once

#include <memory>
#include <string>
#include <vector>

#include "NodeInfo.hpp"
#include "Transformation.hpp"

namespace wayz {
namespace calibration {

class RigidManagerImpl;

class RigidManager final {
public:
    ///
    /// @brief Load transformations from path
    ///
    /// @param path path to folder containing json and yaml formatted
    /// calibration results
    /// @param nodeNames names of nodes of interest
    ///
    RigidManager(const std::string& path, const std::vector<std::string>& nodeNames);

    ~RigidManager();
    RigidManager(RigidManager&& rhs);
    RigidManager& operator=(RigidManager&& rhs);

    ///
    /// @brief Judge if transformations are loaded successfully and ready to use
    ///
    /// @return bool if transformations are loaded successfully and ready to use
    ///
    bool isValid() const;

    ///
    /// @brief Judge if nodes are all connected by valid transformation edges
    ///
    /// @return bool if given nodes () are connected, i.e., transform of arbitrary
    /// node pairs are obtainable.
    ///
    bool isConnected() const;

    ///
    /// @brief Judge if node graph is acyclic
    ///
    /// @return bool if node graph is acyclic, i.e., transformation of arbitrary
    /// node pairs are well-determined.
    ///
    bool isAcyclic() const;

    ///
    /// @brief Judge if transformation between two nodes is obtainable.
    ///
    /// @param nodeNameChild node name of child
    /// @param nodeNameParent node name of parent
    ///
    /// @return bool transformation between given node pairs is obtainable.
    ///
    bool isObtainable(const std::string& nodeNameChild, const std::string& nodeNameParent) const;

    ///
    /// @brief Get the Transformation between child and parent
    ///
    /// @param nodeNameChild node name of child
    /// @param nodeNameParent node name of parent
    ///
    /// @return Transformation T_{parent<-child} satisfies T_pc([R t; 0, 1]) *
    /// x_child(homogenous column vector) = x_parent(homogenous column vector)
    /// if transformation is obtainable return transformation itself, else return arbitrary matrix
    Transformation getTransformation(const std::string& nodeNameChild, const std::string& nodeNameParent) const;

    ///
    /// @brief Get the Node list
    ///
    /// @return std::vector<std::string> node list
    ///
    std::vector<std::string> getNodeList() const;

    ///
    /// @brief Get the Node of node
    ///
    /// @param nodeName node name
    /// @return const NodeInfo& node info of give node
    ///
    NodeInfo getNodeInfo(const std::string& nodeName) const;

private:
    std::unique_ptr<RigidManagerImpl> pImpl_;
};

}  // namespace calibration
}  // namespace wayz