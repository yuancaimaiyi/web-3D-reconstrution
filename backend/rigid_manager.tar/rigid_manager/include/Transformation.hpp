#pragma once

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>

namespace wayz {
namespace calibration {

class Transformation : public Eigen::Matrix4d {
public:
    Transformation() : Eigen::Matrix4d(Eigen::Matrix4d::Identity()) {}

    Transformation(const Eigen::Matrix4d& super) : Eigen::Matrix4d(super) {}

    Transformation(Eigen::Matrix4d&& super) : Eigen::Matrix4d(super) {}
};

}  // namespace calibration
}  // namespace wayz
