#pragma once

#include <array>
#include <stdint.h>

namespace wayz {
namespace calibration {

// For camera
enum class CameraModelType : uint8_t { Undefined = 0, Pinhole = 1, Omni = 2, EUCM = 3, DS = 4 };
enum class DistortionModelType : uint8_t { Undefined = 0, Radtan = 1, Equidistant = 2, FOV = 3, None = 4 };

struct CameraInfo {
    ///
    /// @brief Projection model of camera
    ///
    CameraModelType cameraModel{CameraModelType::Undefined};

    ///
    /// @brief intrinsics of camera
    /// For Pinhole [fx, fy, px, py]
    /// For Omni [xi, fx, fy, px, py]
    /// For EUCM [alpha, beta, fx, fy, px, py]
    /// For DS [xi, alpha, fx, fy, px, py]
    ///
    std::vector<double> intrinsics{};

    ///
    /// @brief Distortion model of camera
    ///
    DistortionModelType distortionModel{DistortionModelType::Undefined};

    ///
    /// @brief distortion coefficients
    /// For Radtan [k1, k2, p1, p2]
    /// For Equidistant [k1, k2, k3, k4]
    /// For FOV [w]
    /// For None []
    ///
    std::vector<double> distortionCoefficients{};

    ///
    /// @brief resolution of camera image
    /// [width(x), height(y)]
    ///
    std::array<int32_t, 2> resolution{0};
};

struct NodeInfo {
    // For Camera

    CameraInfo cameraInfo;

    // For Lidar

    // For IMU

    // For GNSS
};

}  // namespace calibration
}  // namespace wayz
