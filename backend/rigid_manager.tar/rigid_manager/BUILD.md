# 构建和测试

## 依赖

`libyaml-dev, libyaml-cpp-dev, libeigen3-dev`

## 构建

```bash
mkdir -p build
cd build
cmake ..
make
```

## 测试

```bash
./RigidManager-test ../sample_data
```

应该能打印出各传感器刚体变换矩阵

## 打包为 deb

在 `build` 文件夹中

```bash
make package
```

可以得到 `librigid-manager-dev-<version>-Linux.deb

## 安装 deb 文件

```bash
sudo dpkg -i librigid-manager-dev-<version>-Linux.deb
```

## deb 测试

进入 `test/ext` 文件夹，执行

```bash
mkdir -p build
cd build
cmake ..
make
./rigidtest ../../../sample_data/
```

查看是否能打印出变换信息
