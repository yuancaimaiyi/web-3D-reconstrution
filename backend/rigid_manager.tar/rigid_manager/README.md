# RigidManager

载入，计算和管理多个传感器的刚体变换关系。

`RigidManager` 可从文件夹位置或者网络位置载入多个 `json` 或者 `camchain.yaml` 格式的刚体变换(外参数)，并分析各传感器的刚体变换关系。  
判断传感器间的变换关系是否可得到，是否有环路，并提供 API 调用，获得任意两个连通的传感器之间的刚体变换关系。

## API

### 构造

#### 从文件夹载入

```cpp
RigidManager(const std::string& path, const std::vector<std::string>& nodeNames);
```

从文件夹路径 folderPath 载入内含的所有标定文件，nodeNames 是刚体 link 的名字集合，载入成功时候返回 true

#### 从网络地址载入

待实现

### 判断

#### 连通图判断

```cpp
bool isConnected() const;
```

判断载入时传参的 nodeNames 之间的所有节点是否连通

#### 无环路判断

```cpp
bool isAcyclic() const;
```

判断载入的所有标定文件所定义的刚体变换关系是否无环路，若无环路输出 true，此时，每个节点之间的变换都有良好的唯一计算值。

#### 可达性判断

```cpp
bool isObtainable(const std::string& nodeNameChild, const std::string& nodeNameParent) const;
```

判断 nodeNameParent 和 nodeNameChild 两个刚体 link 之间是否可达。

### 刚体变换

#### 获取刚体变换

```cpp
Transformation getTransformation(const std::string& nodeNameChild, const std::string& nodeNameParent) const;
```

获得从 nodeNameChild 到 nodeNameParent 的左乘变换矩阵，即 T\_{parent<-child} 使得 T_pc \* x_child(齐次列向量) = x_parent

#### 刚体变换的转化

将 Transformation 转换为其他类和结构

待补充

## 转换格式

### 转换为 urdf 格式

待补充实现

## 参数文件格式

### `json` 格式

常用格式，其他 `calibration` 工具也输出这种格式。
单个 `json` 文件内可包含单个或多个以下任意一种格式的记述：

1.  四元数格式

```json
{
  "parent": "lidar_top",
  "child": "camera_1",
  "rotation": [0.0, 0.0, 0.707, 0.707],
  "translation": [0.1, 0.05, 0.3]
}
```

其中, `rotation` 为旋转的正则四元数表示，顺序为 `Qx, Qy, Qz, Qw`  
`translation` 为位移的坐标表示，顺序为 `Tx, Ty, Tz`

2. 矩阵格式

```json
{
  "parent": "lidar_top",
  "child": "camera_1",
  "rotation": [0, 1, 0, 1, 0, 0, 0, 0, 1],
  "translation": [0.1, 0.05, 0.3]
}
```

其中, `rotation` 为旋转的矩阵的行优先表示，顺序为 `r11, r12, r13, r21, r22, r23, r31, r32, r33`  
`translation` 为位移的坐标表示，顺序为 `Tx, Ty, Tz`

3. 齐次变换格式

```json
{
  "parent": "lidar_top",
  "child": "camera_1",
  "transformation": [0, 1, 0, 0.1, 1, 0, 0, 0.05, 0, 0, 1, 0.3, 0, 0, 0, 1]
}
```

其中, `transformation` 为齐次变换矩阵的行优先表示

这三种格式中, `parent` 是父级刚体的 link(相当于 urdf 记载格式的 parent)  
`child` 是子级刚体的 link(相当于 urdf 格式的 child)  
注：`parent` 旧名称 `to`, `child` 旧名称 `from` 因有歧义，现已换成与 urdf 一致的。

另外，当单个 `json` 文件中有多个变换关系时，需将各变换关系用一个顶层 Array 包裹。

### `camchain.yaml`格式

该格式由工具 `kalibr` 产出，具体格式不在此详细说明

相机标定格式如下

```yaml
cam0:
  ...
  rostopic: /camera/1/image_raw
cam1:
  T_cn_cnm1:
  - [0, 1, 0, 0.05]
  - [0, 0, -1, -0.08]
  - [-1, 0, 0, -0.01]
  - [0, 0, 0, 1]
  ...
  rostopic: /camera/2/image_raw
...
```

其中, T_cn_cnm1 为，以前一个相机为 child, 后一个相机为 parent 时的齐次变换矩阵。

IMU 标定格式如下

```yaml
cam0:
  ...
  T_cam_imu:
  - [0, 1, 0, 0.05]
  - [0, 0, -1, -0.08]
  - [-1, 0, 0, -0.01]
  - [0, 0, 0, 1]
  ...
  rostopic: /camera/1/image_raw
  imutopic: /imu/internal/imu
```

其中, T_cn_cnm1 为，以 IMU 为 child, 相机为 parent 时的齐次变换矩阵。  
imutopic kalibr 工具输出时候并不加上，需要手工修正。

注：`rostopic`格式和 `linkName` 的转换关系如下

```plain
rostopic = /<name1>/<name2>/... => linkName = <name1>_<name2>
```

如 `/camera/1/image_raw` 被转换为 `camera_1`
