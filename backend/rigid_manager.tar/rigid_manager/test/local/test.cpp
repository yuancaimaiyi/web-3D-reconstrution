#include <iostream>

#include "../include/RigidManager.hpp"

using namespace wayz::calibration;

int main(int argc, char** argv)
{
    if (argc != 2) {
        std::cout << "Usage: rigidtest <folder_of_extrinsices>" << std::endl;
        return -1;
    }
    // std::string folderPath = "../sample/";

    RigidManager rigidManager(argv[1], {"camera_1", "camera_2", "camera_3", "lidar_top"});

    std::cout << "isConnected = " << rigidManager.isConnected() << std::endl;

    std::cout << "isAcyclic = " << rigidManager.isAcyclic() << std::endl;

    std::cout << "T_imu_<-_imu = \n" << rigidManager.getTransformation("imu_internal", "imu_internal") << std::endl;

    std::cout << "T_imu_<-_c1 = \n" << rigidManager.getTransformation("camera_1", "imu_internal") << std::endl;

    std::cout << "T_c1_<-_imu = \n" << rigidManager.getTransformation("imu_internal", "camera_1") << std::endl;

    std::cout << "T_c2_<-_c1 = \n" << rigidManager.getTransformation("camera_1", "camera_2") << std::endl;

    std::cout << "T_c1_<-_lt = \n" << rigidManager.getTransformation("lidar_top", "camera_1") << std::endl;

    std::cout << "T_lt_<-_li = \n" << rigidManager.getTransformation("lidar_inclined", "lidar_top") << std::endl;

    std::cout << "T_li_<-_lt = \n" << rigidManager.getTransformation("lidar_top", "lidar_inclined") << std::endl;

    std::cout << "T_lt_<-_imu = \n" << rigidManager.getTransformation("lidar_top", "imu_internal") << std::endl;

    std::cout << "T_imu_<-_lt = \n" << rigidManager.getTransformation("imu_internal", "lidar_top") << std::endl;

    for (int i = 1; i <= 5; i++) {
        std::cout << "T_" << ("camera_" + std::to_string(i)) << "_->_"
                  << "lidar_top"
                  << " = \n"
                  << rigidManager.getTransformation(("camera_" + std::to_string(i)), "lidar_top") << std::endl;
    }

    RigidManager r2 = std::move(rigidManager);

    std::cout << "T_c2_<-_c1 = \n" << r2.getTransformation("camera_1", "camera_2") << std::endl;

    for (int i = 1; i <= 5; i++) {
        std::string cameraName = "camera_" + std::to_string(i);
        auto nodeInfo = r2.getNodeInfo(cameraName);
        std::cout << "NodeInfo of " << cameraName;
        std::cout << " r[0]: " << nodeInfo.cameraInfo.resolution[0];
        std::cout << " r[1]: " << nodeInfo.cameraInfo.resolution[1];
        std::cout << " i[0]: " << nodeInfo.cameraInfo.intrinsics[0];
        std::cout << " i[1]: " << nodeInfo.cameraInfo.intrinsics[1];
        std::cout << std::endl;
        return 0;
    }
}
