# -*- coding: utf-8 -*-
import os
from setuptools import setup, find_packages


def setup_package():
    package_version = os.system("git describe --abbrev=0")
    if package_version == '':
        package_version = '0.0.0'

    meta_dict = dict(
        name='libhera',
        version=package_version,
        description='Read hera format from python',
        author='zheming.lyu',
        author_email='zheming.lyu@wayz.ai',
        url='https://git.aimap.io/wzautonomy/hera/python',
        packages=find_packages(),
        python_requires='>=3',
        install_requires=['pillow']
    )
    setup(**meta_dict)


if __name__ == '__main__':
    setup_package()
