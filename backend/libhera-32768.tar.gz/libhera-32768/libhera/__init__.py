
import ctypes
from io import StringIO, BytesIO
from typing import List, Optional
from PIL import Image
from enum import Enum

_hera_clib_path = '/usr/local/lib/libhera-capi.so'
_hera_clib_path_2 = '/usr/lib/libhera-capi.so'
try:
    _hera_clib = ctypes.cdll.LoadLibrary(_hera_clib_path)
except:
    try:
        _hera_clib = ctypes.cdll.LoadLibrary(_hera_clib_path_2)
    except:
        print('Can not import libhera capi library from %s, please install it first.')
        raise ImportError('Can not import libhera-capi')


class HeraDataType(Enum):
    CompressedImage = ctypes.c_uint16(0x0401)
    Broken = ctypes.c_uint16(0xFFFF)


class HeraDataMeta(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('sensor_id', ctypes.c_uint32),
        ('sensor_data_type', ctypes.c_uint16),
        ('sequence', ctypes.c_uint32),
        ('timestamp_intrinsic_ns', ctypes.c_uint64)
    ]

    def __repr__(self):
        return (
            "{ <MetaData> "
            "sensor_id = %02u, "
            "sensor_data_type = 0x%04hx, "
            "sequence = %09u, "
            "timestamp_intrinsic_ns = %019lu "
            "}"
        ) % (
            self.sensor_id, self.sensor_data_type, self.sequence,
            self.timestamp_intrinsic_ns
        )


class HeraData(object):
    def __init__(self, data_ptr: ctypes.c_void_p):
        self.data = data_ptr

    def __del__(self):
        _hera_clib.hera_free_data(self.data)
        self.data = ctypes.c_void_p(0)

    def get_meta(self) -> HeraDataMeta:
        """Get meta info of data

        Returns:
            HeraDataMeta: meta info of data
        """

        meta_data = HeraDataMeta()
        _hera_clib.get_meta_data(self.data, ctypes.byref(meta_data))
        return meta_data

    def is_type(self, data_type: HeraDataType) -> bool:
        """Get sensor name of hera storage file

        Args:
            data_type (HeraDataType): enum data type to test
        Returns:
            bool: True if data match given type
        """

        if _hera_clib.data_is_type(self.data, data_type.value) != 0:
            return True
        else:
            return False

    def as_compressed_image(self) -> Optional[Image.Image]:
        """Parse data as PIL.Image

        Returns:
            PIL.Image.Image: image if data is compressed image, otherwise, None
        """
        if not self.is_type(HeraDataType.CompressedImage):
            return None

        image_format = ctypes.c_uint8(0)
        image_len = ctypes.c_uint32(0)
        image_buffer = ctypes.c_void_p(0)

        _hera_clib.data_as_compressed_image(self.data,
                                            ctypes.byref(image_format),
                                            ctypes.byref(image_len),
                                            ctypes.byref(image_buffer)
                                            )

        if(image_buffer.value == 0 or image_len.value == 0):
            return None

        raw_data = (ctypes.c_char *
                    image_len.value).from_address(image_buffer.value)

        file_jpgdata = BytesIO(raw_data)
        image_jpg = Image.open(file_jpgdata)

        return image_jpg


class HeraStorage(object):
    def __init__(self):
        self.fileno = ctypes.c_void_p(0)

    def __del__(self):
        _hera_clib.hera_close(self.fileno)
        self.fileno = ctypes.c_int64(0)

    def open(self, hera_path: str) -> None:
        """Open a hera storage file

        Args:
            hera_path (str): path to hera storage
        """

        c_file_path = ctypes.c_char_p(str(hera_path).encode())
        _hera_clib.hera_open(ctypes.byref(self.fileno), c_file_path)

    def close(self) -> None:
        """Close a hera storage file
        """
        _hera_clib.hera_close(self.fileno)
        self.fileno = ctypes.c_void_p(0)

    def sensor_names(self) -> List[str]:
        """Get sensor names of hera storage file

        Returns:
            List[str]: list of sensor names
        """

        ret = []
        for id in range(_hera_clib.hera_num_sensors(self.fileno)):
            c_name_str = ctypes.c_char_p(0)
            c_sensor_id = ctypes.c_int32(id)
            _hera_clib.hera_sensor_name(
                self.fileno, c_sensor_id, ctypes.byref(c_name_str))
            name_str = c_name_str.value.decode("utf-8")
            ret.append(name_str)
            _hera_clib.hera_free_str(c_name_str)
        return ret

    def read_data(self, index: int = 0) -> Optional[HeraData]:
        """
        Read a sensor data from storage

        Args:
            index (int64): optional, if not 0, read data by index, else, read next data

        Returns:
            HeraData: data if read successfully, None if failed
        """

        c_index = ctypes.c_int64(index)
        c_data = ctypes.c_void_p(0)
        _hera_clib.hera_read_data(self.fileno, ctypes.byref(c_data), c_index)

        if (c_data == 0):
            return None
        else:
            return HeraData(c_data)
