self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f0ff4e6605a59cbf3401",
    "url": "/css/app.195cf607.css"
  },
  {
    "revision": "d55e410f95997df7b1ed",
    "url": "/css/chunk-vendors.4575a2c7.css"
  },
  {
    "revision": "ad8d4c7a6db7417a6e31fffb61dd357b",
    "url": "/index.html"
  },
  {
    "revision": "f0ff4e6605a59cbf3401",
    "url": "/js/app.3d872f70.js"
  },
  {
    "revision": "d55e410f95997df7b1ed",
    "url": "/js/chunk-vendors.4ca4e5ce.js"
  },
  {
    "revision": "67c48d9b37816f5d2e071617486bf2e5",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);