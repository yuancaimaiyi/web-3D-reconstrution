///
/// @file include.hpp
/// @author zheming.lyu (zheming.lyu@wayz.ai)
/// @brief Header for external
/// @version 0.1
/// @date 2019-12-25
///
/// @copyright Copyright 2018 Wayz.ai. All Rights Reserved.
///

#pragma once

// Device Factory
#include "factory.hpp"

// Sensor Data Types
#include "sensor_data_types.hpp"

// Sensor data
#include "data/camera_data.hpp"
#include "data/dummy_data.hpp"
#include "data/gnss_data.hpp"
#include "data/imu_data.hpp"
#include "data/ins_data.hpp"
#include "data/lidar_data.hpp"
#include "data/odometry_data.hpp"