///
/// @file version.hpp
/// @author lyu zheming (zheming.lyu@wayz.ai)
/// @brief
/// @date 2020-04-24
///
/// @copyright Copyright 2018 Wayz.ai. All Rights Reserved.
///
///

#pragma once

#include <string>

namespace wayz {
namespace hera {
namespace device {

std::string get_version();

}  // namespace device
}  // namespace hera
}  // namespace wayz