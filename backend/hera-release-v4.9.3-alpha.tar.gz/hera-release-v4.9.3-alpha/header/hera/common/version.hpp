///
/// @file version.hpp
/// @author lyu zheming (zheming.lyu@wayz.ai)
/// @brief
/// @date 2020-04-24
///
/// @copyright Copyright 2018 Wayz.ai. All Rights Reserved.
///
///

#pragma once

#include <string>

namespace wayz {
namespace hera {
namespace common {

std::string get_version();

}  // namespace common
}  // namespace hera
}  // namespace wayz