///
/// @file ros_message_impl.hpp
/// @author zheming.lyu (zheming.lyu@wayz.ai)
/// @brief Header of implementation of class ROSMessage
/// @date 2019-12-26
///
/// @copyright Copyright 2018 Wayz.ai. All Rights Reserved.
///

#pragma once

#include <geometry_msgs/Vector3Stamped.h>
#include <sensor_msgs/CompressedImage.h>
#include <sensor_msgs/FluidPressure.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/MagneticField.h>
#include <sensor_msgs/NavSatFix.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Temperature.h>

#include "common/include/logger/logger.hpp"
#include "ros_message.hpp"