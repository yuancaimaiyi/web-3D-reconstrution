#pragma once

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

///
/// @brief Open a hera storage file
///
/// @param [out]fileno, if open succeed, 0, otherwise
/// @param hera_path oath of hera storage file
void hera_open(void** fileno, const char* hera_path);

///
/// @brief Get number of sensors of hera storage file
///
/// @param fileno fileno, retrived from hera_open()
/// @return int32_t total number of sensors
///
int32_t hera_num_sensors(void* fileno);

///
/// @brief Get sensor name of hera storage file
///
/// @param fileno fileno, retrived from hera_open()
/// @param sensor_id sensor id
/// @param name sensor name
///
/// @note free name by caller after use
///
void hera_sensor_name(void* fileno, int32_t sensor_id, char** name);

////
/// @brief Free char* created by new
/// 
/// @param str char* string
///
void hera_free_str(char* str);

///
/// @brief Read a sensor data from storage
///
/// @param fileno fileno, retrived from hera_open()
/// @param [out]data, pointer to returning Data(void*)
/// @param index, index of data, if 0, read the next data
/// @return int32_t 0, if read succeed, -1 if failed
///
int32_t hera_read_data(void* fileno, void** data, int64_t index);

///
/// @brief Free the data read from hera_read_data
///
/// @param data pointer to Data(void*)
///
void hera_free_data(void* data);

///
/// @brief Close a hera storage file
///
/// @param fileno
///
void hera_close(void* fileno);

#ifdef __cplusplus
}  // extern "C"
#endif
