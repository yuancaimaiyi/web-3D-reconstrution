#pragma once

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "hera_capi_data_defs.h"

///
/// @brief Get meta data (SensorData) from Data(Void*)
///
/// @param data Data(void*) read from hera_read_data
/// @param [out] sensor_data output of sensor data
void get_meta_data(void* data, struct MetaData* sensor_data);

///
/// @brief Return whether data is a specific type
///
/// @param data Data(void*) read from hera_read_data
/// @param sensor_data_type SensorDataType
/// @return 1 if true, otherwise 0
int32_t data_is_type(void* data, uint16_t sensor_data_type);

///
/// @brief Unpack Data as compressed image
///
/// @param data
/// @param compress_format [out] PNG or JPEG
/// @param image_data_size [out] pointer to image_size
/// @param image_data [out] pointer to void*, storing jpeg data
void data_as_compressed_image(void* data, uint8_t* compress_format, uint32_t* image_data_size, void** image_data);

#ifdef __cplusplus
}  // extern "C"
#endif
