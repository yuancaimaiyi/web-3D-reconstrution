#pragma once

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(push, 1)

#define SensorDataType_CompressedImage (0x0401)

#define CompressFormat_PNG (0x00)
#define CompressFormat_JPEG (0x01)

struct MetaData {
    uint32_t sensor_id;
    uint16_t sensor_data_type;
    uint32_t sequence;
    uint64_t timestamp_intrinsic_ns;
};

#pragma pack(pop)

#ifdef __cplusplus
}  // extern "C"
#endif
